const a="/assets/default-uscRzRXF.png";export{a as d};
